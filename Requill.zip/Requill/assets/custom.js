theme_custom.miniHeightAction = function(selector) {
  var min_height = 0;
  selector.each(function() {
    var height = $(this).outerHeight();
    if (height > min_height) {
      min_height = height;
    }
  });
  return min_height;
};
theme_custom.miniHeight = function(parent, select) {


  var parentWrapper = $(parent).closest(".shopify-section");
  parentWrapper.each(function(index, item) {
    if ($(parent, item).length > 0) {
      var result = theme_custom.miniHeightAction($(select, item));
      $(parent, item).css("height", result);
    }
  });

};

// theme_custom.customReview
theme_custom.customReview = function() {
  var getReviewCustomData = setInterval(function() {
    if ($(".grid__item .stamped-product-reviews-badge .stamped-badge-caption").length > 0 || ($("#slider_recommandation").length > 1)) {
      // console.log($(".grid__item .stamped-product-reviews-badge .stamped-badge-caption"));
      $(".grid__item").each(function() {
        var reviewStartNumber = $(this).find(".stamped-product-reviews-badge .stamped-badge-caption").data("reviews"),
          reviewStartReview = $(this).find(".stamped-product-reviews-badge .stamped-badge-caption").data("rating"),
          reviewHtml = '',
          target = $(this).find(".stamped-product-reviews-badge");
        reviewHtml = `<div class="custom-review-html">
                        <span class="star-icon">
                          <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" enable-background="new 0 0 500 500" height="500px" id="Layer_1" version="1.1" viewBox="0 0 500 500" width="500px" xml:space="preserve"><path clip-rule="evenodd" d="M250,41.034c-8.091,0-14.808,5.448-16.902,12.901l-42.882,132.467  H49.392c-9.724,0-17.442,8.456-17.442,18.26c0,5.999,2.997,11.357,7.54,14.542c2.814,1.907,113.747,82.948,113.747,82.948  s-42.605,130.835-43.431,132.921c-0.63,1.907-1.083,4.001-1.083,6.175c0,9.813,7.897,17.718,17.622,17.718  c3.726,0,7.178-1.181,10.087-3.175L250,373.106c0,0,111.023,80.865,113.569,82.685c2.899,1.994,6.361,3.175,10.078,3.175  c9.725,0,17.63-7.994,17.63-17.718c0-2.174-0.45-4.268-1.092-6.175c-0.815-2.086-43.421-132.921-43.421-132.921  s110.924-81.041,113.744-82.948c4.543-3.185,7.542-8.543,7.542-14.63c0-9.717-7.542-18.172-17.267-18.172H309.961L266.892,53.935  C264.81,46.482,258.081,41.034,250,41.034z" fill="#010101" fill-rule="evenodd" style="fill: #828282;"/></svg>
                        </span>
                        <span class="review-start">
                          ${reviewStartReview}</span>
                        <span class="review-count">
                          (${reviewStartNumber})
                        </span>
                      </div>`;
        target.css("display", "none");
        $(reviewHtml).insertAfter(target);
      });
      clearInterval(getReviewCustomData);
    }
  }, 500);





}

// theme_custom.themeSlider
theme_custom.themeSlider = function() {
  // Homepage Brand Slider

  $('.mobile_details__slider').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 3,
    arrows: false,
    responsive: [{
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: false
      }
    }, {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        dots: true,
      }
    }, {
      breakpoint: 598,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        dots: true,
      }
    }]
  });

  // brands-responsivE
  $('.brands-responsive').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 5,
    slidesToScroll: 1,
    arrows: false,
    responsive: [{
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true
      }
    }, {
      breakpoint: 769,
      settings: {
        slidesToShow: 4
      }
    }, {
      breakpoint: 480,
      settings: {
        slidesToShow: 3
      }
    }]
  });

  // Main Homepage Slider
  $('.hero_sliders').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    appendDots: '.hero_sliders'
  });

  // visible section slider
  $('.product__beforeafter-images-slider').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false
  });

  // Homepage testimonial 
  $('.testimonial').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false
  });

  // Homepage collection Tabs slider
  $('.mobile_slider').slick({
    dots: true,
    infinite: false,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 1,
    arrows: true,
    prevArrow: "<button type='button' class='slick-prev pull-left'><img src='https://cdn.shopify.com/s/files/1/0306/6262/3364/files/left_arrow.png?v=1638268785'></button>",
    nextArrow: "<button type='button' class='slick-next pull-right'><img src='https://cdn.shopify.com/s/files/1/0306/6262/3364/files/right_arrow.png?v=1638268785'></button>",
    responsive: [{
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true
      }
    }, {
      breakpoint: 769,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        arrows: false,
      }
    }, {
      breakpoint: 598,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false
      }
    }]
  });

  // product page slide 
  $('.slider_navs').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows: false,
    dots: false,
    vertical: true,
    verticalSwiping: true,
    infinite: false
  });


  if ($(window).width() < 1023) {
    $('.view_similar_item_btn').click(function() {
      var similarslider = setInterval(function() {
        if ($(".view_similar_product").length > 0) {
          $('.view_similar_product').slick({
            slidesToShow: 2,
            slidesToScroll: 1,
            arrows: false,
            dots: true,
            infinite: false
          });
          clearInterval(similarslider);
        }
      }, 500);

    });
    // product image slider 
    $('ul#large-image').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      dots: true,
      infinite: false

    });

  }

  var recommandslider = setInterval(function() {
    if ($("#slider_recommandation").length > 0) {
      $('#slider_recommandation').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: false,
        dots: true,
        infinite: false,
        responsive: [{
          breakpoint: 769,
          settings: {
            slidesToShow: 3
          }
        }, {
          breakpoint: 749,
          settings: {
            slidesToShow: 2
          }
        }]
      });
      clearInterval(recommandslider);
    }

  }, 500);

  // review 
  var getReviewCustomDatas = setInterval(function() {
    if ($("#slider_recommandation .grid__item .stamped-product-reviews-badge .stamped-badge-caption").length > 0) {
      $("#slider_recommandation .grid__item").each(function() {
        var reviewStartNumber = $(this).find(".stamped-product-reviews-badge .stamped-badge-caption").data("reviews"),
          reviewStartReview = $(this).find(".stamped-product-reviews-badge .stamped-badge-caption").data("rating"),
          reviewHtml = '',
          target = $(this).find(".stamped-product-reviews-badge");
        reviewHtml = `<div class="custom-review-html">
<span class="star-icon">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" enable-background="new 0 0 500 500" height="500px" id="Layer_1" version="1.1" viewBox="0 0 500 500" width="500px" xml:space="preserve"><path clip-rule="evenodd" d="M250,41.034c-8.091,0-14.808,5.448-16.902,12.901l-42.882,132.467  H49.392c-9.724,0-17.442,8.456-17.442,18.26c0,5.999,2.997,11.357,7.54,14.542c2.814,1.907,113.747,82.948,113.747,82.948  s-42.605,130.835-43.431,132.921c-0.63,1.907-1.083,4.001-1.083,6.175c0,9.813,7.897,17.718,17.622,17.718  c3.726,0,7.178-1.181,10.087-3.175L250,373.106c0,0,111.023,80.865,113.569,82.685c2.899,1.994,6.361,3.175,10.078,3.175  c9.725,0,17.63-7.994,17.63-17.718c0-2.174-0.45-4.268-1.092-6.175c-0.815-2.086-43.421-132.921-43.421-132.921  s110.924-81.041,113.744-82.948c4.543-3.185,7.542-8.543,7.542-14.63c0-9.717-7.542-18.172-17.267-18.172H309.961L266.892,53.935  C264.81,46.482,258.081,41.034,250,41.034z" fill="#010101" fill-rule="evenodd" style="fill: #828282;"/></svg>
</span>
<span class="review-start">
${reviewStartReview}</span>
<span class="review-count">
(${reviewStartNumber})
</span>
</div>`;
        target.css("display", "none");
        $(reviewHtml).insertAfter(target);
      });
      clearInterval(getReviewCustomDatas);
    }
  }, 500);


}

// theme_custom.homePageVideo
theme_custom.homePageVideo = function(){
  // Homepage video

  var playButtonClass = '.js-play-button';
  $(document).on('click', playButtonClass, function() {
    let videoSelector = $(this).next(),
      videoObject = videoSelector.get(0);
    $(this).toggleClass('active');

    videoSelector.toggleClass('active');
    $(this).closest('.video_image_banner').toggleClass('video_playing')
    if ($(this).hasClass('youtube_video')) {
      var videoURL = videoSelector.prop('src');
      if (videoSelector.hasClass('active')) {
        videoURL += "&mute=1&autoplay=1";
        videoSelector.prop('src', videoURL);
      } else {
        videoURL = videoURL.replace("&mute=1&autoplay=1", "");
        videoSelector.prop('src', '');
        videoSelector.prop('src', videoURL);
      }
    } else if ($(this).hasClass('vimeo_video')) {
      var player = new Vimeo.Player(videoSelector);
      if (videoSelector.hasClass('active')) {
        player.play();
      } else {
        player.pause();
      }
    } else {
      videoObject.paused ? videoObject.play() : videoObject.pause();
    }
  })
}

// theme_custom.clickEvent
theme_custom.clickEvent = function() {

  // if($(window).width() < 767 && $(".template-collection").length > 0) {
  //   console.log("hello this is collection page ");
  //   $(document).on("click", ".boost-pfs-filter-option .boost-pfs-filter-option-title", function(){
  //     if($(this).hasClass("active")){
  //       $(".boost-pfs-filter-option-content").removeClass("active");
  //       $(".boost-pfs-filter-option .boost-pfs-filter-option-title").removeClass("active");
  //     } else {
  //       $(this).addClass("active");
  //       $(".boost-pfs-filter-option-content").removeClass("active");
  //       $(this).parent(".boost-pfs-filter-option").find(".boost-pfs-filter-option-content").addClass("active");
  //     }
  //   })
  // }


  // Faq Accordion tabs
  $('.product__faqs-accordion li').click(function() {
    $(this).toggleClass('active').siblings().removeClass('active');
  });


  //info text
  // $('#product_info_text').click(function() {
  //   $(".product_info_text_delivery").addClass('display_info');

  // });
  // $('body').click(function() {  
  //   $(".product_info_text_delivery").removeClass('display_info');
  // });
  // pdp countdown 
  const pdpCountDown = setInterval(function() {
    if ($('#countdownultimate-KT .kt-wrapper img').length > 0) {
      $(".kt-timer a").parent().hide();
      $(".kt-timer .kt-head").css({
        'width': '100%',
        'max-width': '60px'
      });
      $(" .kt-timer-component").css({
        'width': '100%',
        'max-width': '310px'
      });
      $(".kt-timer:empty").css({
        'display': 'none'
      });
      $('#countdownultimate-KT').removeClass('hidden');
      clearInterval(pdpCountDown);
    }
  }, 500);


  // megamenu
  $("#megamenu").click(function(e) {
    e.preventDefault();
    $(this).toggleClass("uparrow");
    var parents = $(this).parent();
    $(parents).find("ul").toggle();
  });


  // Homepage  tabs 
  $("[data-toggle='tab']").click(function() {
    $('.tabs_navs button').removeClass('selected')
    $(this).addClass('selected');
    var tabs = $(this).attr('data-tabs');
    var tab = $(this).attr("data-tab");
    $(tabs).find(".gtab").removeClass("active");
    $(tabs).find(tab).addClass("active");
  });

  // Homepage subcollection Tabs
  $(document).on("click", ".subcollections_tabs .tab-header", function() {
    var parent = $(this).closest(".subcollections_tabs").parent();
    var data_tab_val = $(this).data("tab-val");
    var parent = $(this).closest(".collection-wrapper");
    $(parent).find(".tab_collection_cover .c_tabs, .subcollections_tabs .tab-header").removeClass('active');
    $(this).addClass("active");
    $(parent).find(".tab_collection_cover .c_tabs[data-body-val='" + data_tab_val + "']").addClass("active");
  });

  $('ul.learn_tabs li').click(function() {
    var tab_id = $(this).attr('data-tab');
    $('ul.learn_tabs li').removeClass('current');
    $('.learn_tab-content').removeClass('current');

    $(this).addClass('current');
    $("#" + tab_id).addClass('current');
  });

  // View more button 
  $('.moreless-button').click(function() {
    $('.moretext').slideToggle();
    if ($('.moreless-button').text() == "View All Ingredients") {
      $(this).find("strong").text("View Less Ingredients")
    } else {
      $(this).find("strong").text("View All Ingredients")
    }
  });
  // fancybox 
  $('.fancybox-media').click(function() {
    $(this).fancybox({
      openEffect: 'none',
      closeEffect: 'none',
      helpers: {
        media: {}
      }
    });
  });

  // collection page 
  $(document).on("click", ".icon_filter", function() {
    $(this).toggleClass("active_blue");
    if ($(window).width() > 1024) {
      $("#collection_left_bar").toggleClass("left_bar_show");
      $("#collection_right_bar").toggleClass("right_bar_100");
      $(".custom_collection_filter").toggleClass("bg-white");
      if ($(".icon_filter").hasClass("active_blue")) {
        $(".icon_filter .filter_text").text("Hide Filter")
      } else {
        $(".icon_filter .filter_text").text("Filter");
      }
    } else {
      $(".boost-pfs-filter-mobile-footer-custom").remove();
      var closeFilterButtonMobile = `<div class="boost-pfs-filter-mobile-footer-custom"><button class="boost-pfs-filter-button boost-pfs-filter-close-button">Close Filter</button><button class="boost-pfs-filter-button boost-pfs-filter-custom-apply-button">Apply Filter</button></div>`;
      var filterButton = setInterval(function() {
        if ($(".boost-pfs-filter-mobile-footer").length > 0) {
          if ($(window).width() < 768) {
            $(closeFilterButtonMobile).insertAfter(".boost-pfs-filter-mobile-footer");
          }
          clearInterval(filterButton);
        }
      }, 500);
      if ($(".icon_filter").hasClass("active_blue")) {
        $(".icon_filter .filter_text").text("Hide Filter")
        $(".left_bar_show").css({
          "width": "100%",
          "display": "block"
        });
        $('.boost-pfs-filter-left-col-inner .boost-pfs-filter-tree').addClass('boost-pfs-filter-tree-mobile-open');
      } else {
        $(".icon_filter .filter_text").text("Filter");
        $(".left_bar_show").css({
          "width": "0",
          "display": "none"
        });
      }
      $(".boost-pfs-filter-tree-mobile-button button").click();
    }
  });

  if ($(window).width() < 768) {
    $(document).on("click", ".boost-pfs-filter-option .boost-pfs-filter-option-title", function() {
      if ($(this).hasClass("active")) {
        $(this).removeClass("active");
        $(this).siblings(".boost-pfs-filter-option-content").removeClass("open");
      } else {
        $(this).addClass("active");
        $(this).siblings(".boost-pfs-filter-option-content").addClass("open");
      }
    });
  }

  // List view 
  $(document).on("click", ".filter_icon_withcover .list-view-icon", function() {
    $(".grid_view").removeClass("active_blue");
    $(this).find(".maximize").addClass("active_blue");
    $("#main-collection-product-grid, .template-collection .collection").addClass("full-width");
    $("#main-collection-product-grid .grid__item, .template-collection .collection").addClass("W__100");
  });

  //grid view
  $(document).on("click", ".filter_icon_withcover .grid-view-icon", function() {
    $(".filter_icon_withcover .maximize").removeClass("active_blue");
    $(this).find(".grid_view").addClass("active_blue");
    $("#main-collection-product-grid, .template-collection .collection").removeClass("full-width");
    $("#main-collection-product-grid .grid__item, .template-collection .collection").removeClass("W__100");
  });

  // close mobile filter    
  $(document).on("click", ".boost-pfs-filter-button.boost-pfs-filter-close-button, .boost-pfs-filter-button.boost-pfs-filter-custom-apply-button,.boost-pfs-filter-clear-all", function() {
    $(".boost-pfs-filter-close").click();
    $(".icon_filter").click();
    $(".boost-pfs-filter-option-title").removeClass("active");
    $(".boost-pfs-filter-option-content").removeClass("open");
  });






  $(document).on('click', '.pdp-page-tab.container-new a[href^="#"]', function(e) {
    // target element id
    var id = $(this).attr('href');

    // target element
    var $id = $(id);
    if ($id.length === 0) {
      return;
    }

    // prevent standard hash navigation (avoid blinking in IE)
    e.preventDefault();

    // top position relative to the document
    var pos = $id.offset().top;
    $(this).siblings().removeClass("active_tab");
    $(this).addClass("active_tab");
    // animated top scrolling
    $('body, html').animate({
      scrollTop: pos
    });
  });
};

// theme_custom.onChange
theme_custom.onChange = function() {
  // product page quantity selector
  $('.qty_class select.quantity__input').change(function() {
    var $option = $(this).find('option:selected');
    var value = $option.val();
    var text = $option.text();
    var price = $('.price_cart_brn').text(),
        data_attr = $('.price_cart_brn').attr("data-price-btn");
    
    var amount = Number( price.replace(/[^0-9\.]+/g,""));
    var currency = price.match(/[^\d,]/g).join('');
    var damount = Number( data_attr.replace(/[^0-9\.]+/g,""));
    var dcurrency = data_attr.match(/[^\d,]/g).join('');
    var amt =  parseInt(damount),
        cur = parseInt(value),
        total_price = amt * cur;
    $('.price_cart_brn').text(currency + total_price);
    $('.price_cart_brns').text(currency + total_price);
    

    $('.qty_class .quantity_input_product').val(value);
    if (value == 10) {
      $('.qty_class select.quantity__input').hide();
      $('.qty_class svg').hide();
      $('.qty_class .quantity_input_product').show();
    }
  });

  //cart quantity selector
  $('.qty_class select.quantity__input_cart').change(function() {
    var $option = $(this).find('option:selected');
    var value = $option.val();
    var text = $option.text();

    $('.qty_class .quantity_input_product_cart').val(value);
    if (value == 10) {
      $('.qty_class select.quantity__input_cart').hide();
      $('.qty_class svg').hide();
      $('.qty_class .quantity_input_product_cart').show();
    }
  });





  $(".quantity_input_product").keyup(function() {
    var dInput = $(this).val().length;  
    if(dInput > 1){
    var dInput1 = $(this).val();
    var price = $('.price_cart_brn').text(),
    data_attr = $('.price_cart_brn').attr("data-price-btn");

    var amount = Number( price.replace(/[^0-9\.]+/g,""));
    var currency = price.match(/[^\d,]/g).join('');
    var damount = Number( data_attr.replace(/[^0-9\.]+/g,""));
    var dcurrency = data_attr.match(/[^\d,]/g).join('');
    var amt =  parseInt(damount),
    cur = parseInt(dInput1),
    total_price = amt * cur;
    $('.price_cart_brn').text(currency + total_price);
    $('.price_cart_brns').text(currency + total_price);
  }
      

  
      

  });


};

//Megamenu Hover
theme_custom.onHover = function() {
  $(".has-parent-dropdown").mouseover(function() {
    var area_val = $(this).attr("aria-controls");
    var next = $(this).next().attr("id");
    if (area_val == next) {
      $(this).next().find("ul li.has-child-dropdown").siblings().removeClass("item-active");
      $(this).next().find("ul li.has-child-dropdown:first-child").addClass("item-active");
      

    }
    $(this).next().find("ul li.has-child-dropdown").siblings().mouseover(function() {
      $(this).siblings().removeClass("item-active");
      $(this).addClass("item-active");
    });
    
    
  });
};

// theme_custom.formValidation
theme_custom.formValidation = function() {
  $(".form_email").bind("keypress keyup keydown", function(e) {
    if (e.which == 32) {
      return false;
    }
    if ($(this).closest(".form-wrap").find(".form-error.active").length > 0) {
      $(this).closest(".form-wrap").find(".form-error.active").removeClass("active");
    }
    // theme_custom.emailValidation($(this));
  });
  $(".form_field").bind("keypress keyup keydown", function(e) {
    if (e.which == 32) {
      return false;
    }
    theme_custom.fieldValidation($(this));
  });
  $('.form_name').bind("keyup", function(e) {
    theme_custom.nameValidation($(this));
  });

  $(".form_phone").bind("keypress keyup keydown", function(e) {
    theme_custom.phoneValidation($(this));
  });
};

//theme_custom.emailValidation
theme_custom.emailValidation = function($this) {
  var count = 0;
  var parent = $this.closest(".form-wrap");
  if ($this.val() == "" || $.trim($this.val()) == '') {
    parent.find('.form-error').text('This field is required').addClass("active");
    var count = 1;
  } else {
    function ValidateEmail(email) {
      var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      return expr.test(email);
    };
    if (!ValidateEmail($this.val())) {
      parent.find('.form-error').text('Please enter valid email').addClass("active");
      var count = 1;
    } else {
      parent.find('.form-error').removeClass("active");
    }
  }
  return count;
}

// theme_custom.fieldValidation
theme_custom.fieldValidation = function($this) {
  var count = 0;
  var parent = $this.closest(".form-wrap");
  var passwordMinlength = parseInt($this.attr("minlength"));
  var passwordMaxlength = parseInt($this.attr("maxlength"));

  if ($this.val() == "" || $.trim($this.val()) == '') {
    parent.find('.form-error').text('This field is required').addClass("active");
    count = 1;
  } else {
    if ($this.val().length > passwordMaxlength || $this.val().length < passwordMinlength) {
      parent.find('.form-error').text('Please enter minimum ' + passwordMinlength + ' & maximum length ' + passwordMaxlength + ' ! ').addClass("active");
      count = 1;
    } else {
      parent.find('.form-error').removeClass("active");
    }
  }
  return count;
};


theme_custom.selectchangeEvent = function() {
  // start event-type change event
  $(document).on('change', '#ContactForm-QueryType', function() {
    var parent = $(this).closest(".form-wrap");
    parent.find('.form-error').removeClass("active");
  });
  // end event-type change event
}


// theme_custom.scroll
theme_custom.scroll = function() {
  $(window).scroll(function(event) {
    var scroll = $(window).scrollTop();
    var height = $(window).height();
    if (scroll > height) {
      $('.arrow-up').show();
    } else {
      $('.arrow-up').hide();
    }

    if ($(".template-collection") && $(window).width() > 1024) {
      var headerHeight = $("#shopify-section-header").height() + 20;
      if ($("#shopify-section-header.shopify-section-header-hidden").length > 0 && $("#CollectionProductGrid").length > 0) {
        $("#collection_left_bar").css({
          "position": "sticky",
          "top": "20px"
        });
      } else {
        $("#collection_left_bar").css({
          "position": "sticky",
          "top": headerHeight + "px"
        });
      }
    }
  });
}

// theme load 
theme_custom.load = function() {
  if ($("#CollectionProductGrid").length > 0) {
    var getProductItem = setInterval(function() {
      if ($("#main-collection-product-grid .grid__item").length > 0) {
        $(".loading-overlay-wrapper").hide();
        $(".boost-pfs-filter-wrapper").fadeIn("slow");
        clearInterval(getProductItem);
      }
    }, 500);
  }

  // MiniHeight Function
  var collectionPageItemTitle = setInterval(function() {
    if ($("#main-collection-product-grid .card-information__text.h5 .full-unstyled-link").length > 0) {
      var collectionPageTitleParent = "#main-collection-product-grid .card-information__text.h5";
      var collectionPageTitleChild = "#main-collection-product-grid .card-information__text.h5 .full-unstyled-link";
      theme_custom.miniHeight(collectionPageTitleParent, collectionPageTitleChild);
      clearInterval(collectionPageItemTitle);
    }
  }, 500)
  var gridProductTitleParent = ".collection .grid__item .card-information__text.h5";
  var gridProductTitleChild = ".collection .grid__item .card-information__text.h5 .full-unstyled-link";
  $(window).load(function() { //window load
    theme_custom.miniHeight(gridProductTitleParent, gridProductTitleChild);
  });
}



theme_custom.formValidation = function() {
  $(".form_email").bind("keypress keyup keydown", function(e) {
    if (e.which == 32) {
      return false;
    }
    if ($(this).closest(".form-wrap").find(".form-error.active").length > 0) {
      $(this).closest(".form-wrap").find(".form-error.active").removeClass("active");
    }
    // theme_custom.emailValidation($(this));
  });
  $(".form_field").bind("keypress keyup keydown", function(e) {
    if (e.which == 32) {
      return false;
    }
    theme_custom.fieldValidation($(this));
  });
  $('.form_name').bind("keyup", function(e) {
    theme_custom.nameValidation($(this));
  });

  $(".form_phone").bind("keypress keyup keydown", function(e) {
    theme_custom.phoneValidation($(this));
  });
};

//theme_custom.emailValidation
theme_custom.emailValidation = function($this) {
  var count = 0;
  var parent = $this.closest(".form-wrap");
  if ($this.val() == "" || $.trim($this.val()) == '') {
    parent.find('.form-error').text('This field is required').addClass("active");
    var count = 1;
  } else {
    function ValidateEmail(email) {
      var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      return expr.test(email);
    };
    if (!ValidateEmail($this.val())) {
      parent.find('.form-error').text('Please enter valid email').addClass("active");
      var count = 1;
    } else {
      parent.find('.form-error').removeClass("active");
    }
  }
  return count;
}

// theme_custom.fieldValidation
theme_custom.fieldValidation = function($this) {
  var count = 0;
  var parent = $this.closest(".form-wrap");
  var passwordMinlength = parseInt($this.attr("minlength"));
  var passwordMaxlength = parseInt($this.attr("maxlength"));

  if ($this.val() == "" || $.trim($this.val()) == '') {
    parent.find('.form-error').text('This field is required').addClass("active");
    count = 1;
  } else {
    if ($this.val().length > passwordMaxlength || $this.val().length < passwordMinlength) {
      parent.find('.form-error').text('Please enter minimum ' + passwordMinlength + ' & maximum length ' + passwordMaxlength + ' ! ').addClass("active");
      count = 1;
    } else {
      parent.find('.form-error').removeClass("active");
    }
  }
  return count;
}

// theme_custom.nameValidation
theme_custom.nameValidation = function($this) {
  var count = 0;
  var parent = $this.closest(".form-wrap");
  var regex = new RegExp("^[a-zA-Z]{3,49}$");
  var str = $this.val();
  if ($this.val() == "" || $.trim($this.val()) == '') {
    parent.find('.form-error').text('This field is required').addClass("active");
    count = 1;
  } else if ($this.length > 0) {
    if ($this.val().length > 49) {
      if ($this.val().length > 49) {
        parent.find(".form-error").text('First name is too long (maximum is 50 characters)').addClass("active");
      } else {
        parent.find(".form-error").text('First name is too long (maximum is 50 characters)').removeClass("active");
      }
    } else {
      parent.find(".form-error").text('First name is too long (maximum is 50 characters)').removeClass("active");
      if (regex.test(str)) {
        parent.find(".form-error").text('Please enter Alphabets').removeClass("active");
      } else if ($this.val().length < 3) {
        parent.find(".form-error").text('Please enter Alphabets (minimum is 3 characters).').addClass("active");
      } else {
        parent.find(".form-error").text('Please enter only Alphabets').addClass("active");
        count = 1;
      }
    }
  } else {
    parent.find(".form-error").removeClass("active");
  }
  return count;
}

// theme_custom.phoneValidation
theme_custom.phoneValidation = function($this) {
  var count = 0;
  var parent = $this.closest(".form-wrap");
  let targetEl = $this.val().length;
  var numbers = /^[0-9]+$/;
  if ($this.val() == "") {
    parent.find('.form-error').text('This field is required').addClass("active");
    count = 1;
  } else if (!$this.val().match(numbers)) {
    parent.find(".form-error").text('Please enter only number').addClass("active");
    count = 1;
  } else {
    if (targetEl < 9) {
      parent.find(".form-error").text('Please enter minimum 9 characters').addClass("active");
      count = 1;
    } else if (targetEl > 14) {
      parent.find(".form-error").text('Please enter maximum 14 characters').addClass("active");
      count = 1;
    } else {
      parent.find(".form-error").removeClass("active");
    }
  }
  return count;
}

theme_custom.selectchangeEvent = function() {
  // start event-type change event
  $(document).on('change', '#ContactForm-QueryType', function() {
    var parent = $(this).closest(".form-wrap");
    parent.find('.form-error').removeClass("active");
  });
  // end event-type change event

}

// theme_custom.submitEvent
theme_custom.submitEvent = function() {
  $('.contact-form').submit(function(e) {
    var error_count = 0;
    error_count = error_count + theme_custom.nameValidation($(this).find('[name="contact[Name]"]'));
    error_count = error_count + theme_custom.emailValidation($(this).find('[name="contact[email]"]'));
    error_count = error_count + theme_custom.phoneValidation($(this).find('[name="contact[Phone number]"]'));
    error_count = error_count + theme_custom.fieldValidation($(this).find('[name="contact[Comment]"]'));
    error_count = error_count + theme_custom.fieldValidation($(this).find('[name="contact[OrderNumber]"]'));
    error_count = error_count + theme_custom.fieldValidation($(this).find('[name="contact[subject]"]'));
    error_count = error_count + theme_custom.fieldValidation($(this).find('[name="contact[QueryType]"]'));
    if (error_count > 0) {
      e.preventDefault();
      return false;
    }
  });
}

// theme_custom.init
theme_custom.init = function() {
  theme_custom.themeSlider();
  theme_custom.homePageVideo();
  theme_custom.formValidation();
  theme_custom.submitEvent();
  theme_custom.onChange();
  theme_custom.clickEvent();
  theme_custom.scroll();
  theme_custom.load();
  theme_custom.selectchangeEvent();
  theme_custom.onHover();
  if ($(".template-collection").length > 0 || $(".template-search").length > 0) {
    var collectionPageReview = setInterval(function() {
      if ($("#CollectionProductGrid .grid__item .stamped-product-reviews-badge .stamped-badge-caption").length > 0) {
        theme_custom.customReview();
        clearInterval(collectionPageReview);
      }
    }, 500);
  } else {
    theme_custom.customReview();
  }
}

document.addEventListener('readystatechange', event => {
  if (event.target.readyState === "complete") {
    if ($(".contact-form").length > 0) {
      var contactformpagesubmit = setInterval(function() {
        if ($(".contact-form[onsubmit]").length > 0) {
          $(".contact-form").removeAttr("onsubmit");
          $(".button").removeClass("disable");
          clearInterval(contactformpagesubmit);
        }
      }, 100);
    }
    if ($("#ContactFooter").length > 0) {
      var contactformfooterpagesubmit = setInterval(function() {
        if ($("#ContactFooter[onsubmit]").length > 0) {
          $("#ContactFooter").removeAttr("onsubmit");
          clearInterval(contactformfooterpagesubmit);
        }
      }, 100);
      setTimeout(function() {
        $('.newsletter-form__message').css('display', 'none');
      }, 10000);
    }
  }
});

$(document).ready(function() {

  // menubar	
  $('summary.has-parent-dropdown').on('mouseenter click', function(e) {
    e.stopPropagation();
  });

  // scrollTop js 	

  $('.dt-sc-to-top').on('click', function(e) {
    e.preventDefault();
    $('html, body').stop().animate({
      scrollTop: $('html, body').offset().top,
    }, 900, 'swing', function() {});
  });

  function cartdata() {
    $.ajax({
      type: 'GET',
      dataType: 'html',
      url: '/cart?view=icart',
      success: function(result) {
        var data_get = $(result).find('#shopify-section-main-cart-items').html();
        $("#cart__drawer").html(data_get);
      }
    });
  }

  function cartdatapost() {
    $.ajax({
      type: "POST",
      url: '/cart/update.js',
      data: $('form[action="/cart"]').serialize(),
      success: function(data) {
        cartdata();
      }

    });
  }
  $(document).on('click', '.quantity__input [name="updates[]"]', function(e) {
    cartdatapost();
  });


  // update item cart function


  $(document).on("change", ".quantity__input_cart", function() {
    var $parentElm = $(this);

    setTimeout(function() {
      var update_val = $parentElm.val();
      var data_id = $parentElm.attr("data-var-id");
      var line = $parentElm.attr("data-line");
      var data = {
        quantity: update_val,
        id: data_id
      };
      $.ajax({
        type: "POST",
        url: "/cart/change.js",
        data: data,
        dataType: "json",
        success: function(data) {
          alert(Shopify.formatMoney(data.total_price, "₹ {{amount}}"));
        },
      });
    }, 100);

  });
  
  document.addEventListener('readystatechange', event => {
    if (event.target.readyState === "complete") {

      if ($(".contact-form").length > 0) {
        var contactformpagesubmit = setInterval(function() {
          if ($(".contact-form[onsubmit]").length > 0) {
            $(".contact-form").removeAttr("onsubmit");
            $(".button").removeClass("disable");
            clearInterval(contactformpagesubmit);
          }
        }, 100);
      }
    }
  });


// collection page filter product count 


// if($(window).width() > 767){
//   setTimeout(function(){
//     var product_filter_count = $('.boost-pfs-filter-option-item-list.boost-pfs-filter-option-item-list-multiple-list li.selected').length;
//     $("#filtered_product_count").text("(" + product_filter_count + ")");
//   },800)
// $(document).on("click",".boost-pfs-filter-option-label , .boost-pfs-filter-clear-all", function(){
//   setTimeout(function(){
//       var product_filter_count = $('.boost-pfs-filter-option-item-list.boost-pfs-filter-option-item-list-multiple-list li.selected').length;
//       $("#filtered_product_count").text("(" + product_filter_count + ")");
//       theme_custom.customReview();
//   },800)
    
// });
// }
  $(document).on("click",".boost-pfs-filter-custom-apply-button", function(){
    setTimeout(function(){
        theme_custom.customReview();
    },800)  
  });

$(document).on("click",".write_comment_btn", function() {
  $(".show_add_comment").toggle();
  $(".show_add_comment").toggleClass("active");
});

$(document).on("click",".comment-close", function() {
	$(".show_add_comment").hide();
	$(".show_add_comment").removeClass("active");
});
	// $(".product-form__submit").click(function(){
	//   setTimeout(function(){ cartdata(); }, 3000);

  if($(window).width() < 767){
    $(".icon_filter").click(function(){
      $(".boost-pfs-filter-options-wrapper").find(".boost-pfs-filter-option:first-child .boost-pfs-filter-option-title").addClass("active");
      $(".boost-pfs-filter-options-wrapper").find(".boost-pfs-filter-option:first-child .boost-pfs-filter-option-content").addClass("open");
    });
   
  }
  theme_custom.init();



  const interval_productreview = setInterval(review_datas, 2000);
  function review_datas (){
    var data_rating = $(".custom_review .stamped-badge .stamped-badge-caption").attr("data-rating");
    var data_reviews = $(".custom_review .stamped-badge .stamped-badge-caption").attr("data-reviews");
    var product_review_html = `<span class="data_rating">${data_rating}</span><span>(${data_reviews}) | View Reviews</span>`;
    $(".custom_review .stamped-badge-caption").html(product_review_html);
    clearInterval(interval_productreview);
  }
  if($(window).width() < 1024){
  $('#product_info_text').click(function(){
    $('.product_info_text_delivery').toggle();
  });
  }



  if($(window).width() > 1100){
    console.log(window.location.href);
    if(window.location.href == "https://www.reequil.com/collections/sales-offers"){
      
    }
    else{
      $(".icon_filter").trigger("click");
    }
  
  }

});